#pragma merger("0","/tmp/cil-9pUAR25J.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 9 "a.c"
struct Box {
  void *payload;
};

void consume_int_box(struct Box *b) {
  int *p = b->payload;
  *p += 1;
}

void consume_char_box(struct Box *b) {
  char *p = b->payload;
  *p += 1;
}

void run(void *x, int tag) {
  struct Box box;
  box.payload = x;
  void (*cb)(struct Box *);
  if (tag)
    cb = consume_int_box;
  else
    cb = consume_char_box;
  cb(&box);
}
