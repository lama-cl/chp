#pragma merger("0","/tmp/cil-2rBH9_3G.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






void run(void *x) {
  int *p = x;
  *p += 1;
}
