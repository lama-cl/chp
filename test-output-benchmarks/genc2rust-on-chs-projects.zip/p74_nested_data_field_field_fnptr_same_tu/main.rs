#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Box_0<T0> {
    pub payload: *mut T0,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Context<T0> {
    pub box_0: Box_0::<T0>,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Ops {
    pub consume: Option::<unsafe extern "C" fn(*mut Context::<libc::c_void>) -> ()>,
}
pub unsafe extern "C" fn consume_ctx<T0>(mut c: *mut Context::<T0>) {
    let mut p: *mut libc::c_int = (*c).box_0.payload as *mut libc::c_int;
    *p += 1 as libc::c_int;
}
pub unsafe extern "C" fn run<T0>(mut x: *mut T0) {
    let mut ctx: Context::<T0> = Context {
        box_0: Box_0 { payload: 0 as *mut T0 },
    };
    let mut ops: Ops = Ops { consume: None };
    ctx.box_0.payload = x;
    ops
        .consume = Some(
        consume_ctx as unsafe extern "C" fn(*mut Context::<libc::c_void>) -> (),
    );
    (ops.consume)
        .expect("non-null function pointer")(&mut ctx as *mut Context::<libc::c_void>);
}
