#pragma merger("0","/tmp/cil-1192OrHI.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






struct Box {
  void *payload;
};

struct Context {
  struct Box box;
};

struct Ops {
  void (*consume)(struct Context *);
};

void consume_ctx(struct Context *c) {
  int *p = c->box.payload;
  *p += 1;
}

void run(void *x) {
  struct Context ctx;
  struct Ops ops;

  ctx.box.payload = x;
  ops.consume = consume_ctx;
  ops.consume(&ctx);
}
