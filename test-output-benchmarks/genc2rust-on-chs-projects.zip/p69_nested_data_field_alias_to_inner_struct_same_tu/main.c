#pragma merger("0","/tmp/cil-nl8G58Cp.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 10 "a.c"
struct Box {
  void *payload;
};

struct Context {
  struct Box box;
};

void consume_box(struct Box *b) {
  int *p = b->payload;
  *p += 1;
}

void run(void *x) {
  struct Context ctx;
  ctx.box.payload = x;

  struct Box *bp = &ctx.box;
  consume_box(bp);
}
