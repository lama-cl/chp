#pragma merger("0","/tmp/cil-jrRvZ5vs.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 10 "a.c"
void g(void *);

void f(void *x) {
  g(x);
}

int main(void) {
  int i = 0;
  f(&i);
  return i;
}
