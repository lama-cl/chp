#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
extern "C" {
    fn g(_: *mut libc::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn f(mut x: *mut libc::c_void) {
    g(x as *mut libc::c_void);
}
unsafe fn main_0() -> libc::c_int {
    let mut i: libc::c_int = 0 as libc::c_int;
    f(&mut i as *mut libc::c_int as *mut libc::c_void);
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
