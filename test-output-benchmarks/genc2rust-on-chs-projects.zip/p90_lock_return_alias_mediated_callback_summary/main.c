#pragma merger("0","/tmp/cil-wF2d1ss5.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 13 "a.c"
void *idv(void *x) {
  int *pi = x;
  *pi += 1;
  return pi;
}

void *fret(void *x) {
  char *pc = x;
  *pc += 1;
  return x;
}

void ho(void *(*pf)(void *), void *pvho) {
  char *pcho = pvho;
  pf(pcho);
}

void demo(int tag) {
  int i = 0;
  int *pi = &i;
  void *pv = pi;
  void *(*pf)(void *) = 0;

  if (tag)
    pf = idv;
  else
    pf = fret;

  ho(pf, pv);
}
