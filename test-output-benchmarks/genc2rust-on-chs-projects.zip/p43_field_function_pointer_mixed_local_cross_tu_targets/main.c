#pragma merger("0","/tmp/cil-Q3eggIl0.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"




void external_handle(void *x) {
  char *p = x;
  *p += 1;
}
