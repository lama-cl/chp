#pragma merger("0","/tmp/cil-Kh3wcL6D.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"
extern void f(void *x);

void g(void *x) {
  int *pi = x;
  f(pi);
}
