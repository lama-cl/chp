#pragma merger("0","/tmp/cil-GxL3D2pZ.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 9 "a.c"
struct Box {
  void *payload;
};

struct Ops {
  void (*consume)(struct Box *);
};

void consume_box(struct Box *b) {
  int *p = b->payload;
  *p += 1;
}

void run(struct Ops *ops, void *x) {
  struct Box box;
  box.payload = x;
  ops->consume = consume_box;
  ops->consume(&box);
}
