#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Ops {
    pub process: Option::<unsafe extern "C" fn(*mut libc::c_void) -> ()>,
}
pub unsafe extern "C" fn handle_char<T0>(mut x: *mut T0) {
    let mut p: *mut libc::c_char = x as *mut libc::c_char;
    *p = (*p as libc::c_int + 1 as libc::c_int) as libc::c_char;
}
#[no_mangle]
pub static mut base: Ops = unsafe {
    {
        let mut init = Ops {
            process: Some(handle_char as unsafe extern "C" fn(*mut libc::c_void) -> ()),
        };
        init
    }
};
pub unsafe extern "C" fn run<T0>(mut x: *mut T0) {
    let mut local: Ops = base;
    (local.process).expect("non-null function pointer")(x as *mut libc::c_void);
}
