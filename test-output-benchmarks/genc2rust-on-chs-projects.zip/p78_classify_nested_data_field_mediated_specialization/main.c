#pragma merger("0","/tmp/cil-bxEz6udD.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






struct Box {
  void *payload;
};

struct Context {
  struct Box box;
};

void run(void *x) {
  struct Context ctx;
  ctx.box.payload = x;

  int *p = ctx.box.payload;
  *p += 1;
}
