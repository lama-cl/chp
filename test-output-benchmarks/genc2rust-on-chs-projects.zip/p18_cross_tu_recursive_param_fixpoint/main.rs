#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
extern "C" {
    fn f(x: *mut libc::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn g(mut x: *mut libc::c_void) {
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    f(pi as *mut libc::c_void as *mut libc::c_void);
}
