#pragma merger("0","/tmp/cil-JDtdaHGS.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"


void parse_int(void *x) {
  int *p = x;
  *p += 1;
}

void emit_char(void *x) {
  char *p = x;
  *p += 1;
}
