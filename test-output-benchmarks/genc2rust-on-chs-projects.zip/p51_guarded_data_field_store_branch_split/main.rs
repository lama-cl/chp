#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Box_0<T0> {
    pub payload: *mut T0,
}
pub unsafe extern "C" fn run<T0>(mut a: *mut T0, mut b: *mut T0, mut tag: libc::c_int) {
    let mut box_0: Box_0::<T0> = Box_0 { payload: 0 as *mut T0 };
    if tag != 0 {
        box_0.payload = a;
    } else {
        box_0.payload = b;
    }
    let mut p: *mut libc::c_int = box_0.payload as *mut libc::c_int;
    *p += 1 as libc::c_int;
}
