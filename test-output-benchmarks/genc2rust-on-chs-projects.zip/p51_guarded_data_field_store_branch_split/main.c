#pragma merger("0","/tmp/cil-OlsH_3Y2.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"







struct Box {
  void *payload;
};

void run(void *a, void *b, int tag) {
  struct Box box;

  if (tag)
    box.payload = a;
  else
    box.payload = b;

  int *p = box.payload;
  *p += 1;
}
