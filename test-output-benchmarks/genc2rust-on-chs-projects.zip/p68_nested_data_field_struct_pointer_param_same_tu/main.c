#pragma merger("0","/tmp/cil-IFkwUT7L.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"







struct Box {
  void *payload;
};

struct Context {
  struct Box box;
};

void consume_ctx(struct Context *c) {
  int *p = c->box.payload;
  *p += 1;
}

void run(void *x) {
  struct Context ctx;
  ctx.box.payload = x;
  consume_ctx(&ctx);
}
