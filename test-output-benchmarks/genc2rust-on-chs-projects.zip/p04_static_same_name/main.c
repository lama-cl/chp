#pragma merger("0","/tmp/cil-xMH6lbQC.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"







static void helper(void *x) {
  char *p = x;
  *p += 1;
}

void fb(void *x) {
  helper(x);
}
