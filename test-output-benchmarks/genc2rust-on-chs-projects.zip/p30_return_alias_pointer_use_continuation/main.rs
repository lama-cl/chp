#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn idv<T0>(mut x: *mut T0) -> *mut T0 {
    let mut p: *mut libc::c_int = x as *mut libc::c_int;
    return p as *mut T0;
}
