#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn fret<T0>(mut pvf: *mut T0) -> *mut T0 {
    let mut pc: *mut libc::c_char = pvf as *mut libc::c_char;
    *pc = (*pc as libc::c_int + 1 as libc::c_int) as libc::c_char;
    return pvf;
}
pub unsafe extern "C" fn idv<T0>(mut x: *mut T0) -> *mut T0 {
    let mut pidv: *mut libc::c_int = x as *mut libc::c_int;
    *pidv = *pidv + 1 as libc::c_int;
    return pidv as *mut T0;
}
#[no_mangle]
pub unsafe extern "C" fn ho(
    mut pf: Option::<unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void>,
    mut pvho: *mut libc::c_void,
) {
    let mut pcho: *mut libc::c_char = pvho as *mut libc::c_char;
    pf
        .expect(
            "non-null function pointer",
        )(pcho as *mut libc::c_void as *mut libc::c_void);
}
unsafe fn main_0() -> libc::c_int {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut pi1: *mut libc::c_int = &mut i;
    let mut pv: *mut libc::c_void = pi1 as *mut libc::c_void;
    let mut pfunc: Option::<
        unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    > = Some(idv as unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void);
    ho(pfunc, pv);
    pfunc = Some(fret as unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void);
    ho(pfunc, pv);
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
