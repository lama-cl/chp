#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
extern "C" {
    fn local_handle(x: *mut libc::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn external_handle(mut x: *mut libc::c_void) {
    let mut p: *mut libc::c_char = x as *mut libc::c_char;
    *p = (*p as libc::c_int + 1 as libc::c_int) as libc::c_char;
    local_handle(p as *mut libc::c_void as *mut libc::c_void);
}
