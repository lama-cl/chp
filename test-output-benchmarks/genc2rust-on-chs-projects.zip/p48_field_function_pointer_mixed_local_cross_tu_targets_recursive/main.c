#pragma merger("0","/tmp/cil-5lQYyowg.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"




extern void local_handle(void *x);

void external_handle(void *x) {
  char *p = x;
  *p += 1;

  local_handle(p);
}
