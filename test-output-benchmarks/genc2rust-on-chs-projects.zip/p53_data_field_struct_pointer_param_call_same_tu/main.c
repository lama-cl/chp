#pragma merger("0","/tmp/cil-mCb2xxlU.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 10 "a.c"
struct Box {
  void *payload;
};

void consume(void *v) {
  char *p = v;
  *p += 1;
}

void consume_box(struct Box *b) {
  consume(b->payload);
}

void run(void *x) {
  struct Box box;
  box.payload = x;
  consume_box(&box);
}
