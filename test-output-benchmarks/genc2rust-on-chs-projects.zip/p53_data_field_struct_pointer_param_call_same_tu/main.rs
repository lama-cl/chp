#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Box_0<T0> {
    pub payload: *mut T0,
}
pub unsafe extern "C" fn consume<T0>(mut v: *mut T0) {
    let mut p: *mut libc::c_char = v as *mut libc::c_char;
    *p = (*p as libc::c_int + 1 as libc::c_int) as libc::c_char;
}
pub unsafe extern "C" fn consume_box<T0>(mut b: *mut Box_0::<T0>) {
    consume((*b).payload);
}
pub unsafe extern "C" fn run<T0>(mut x: *mut T0) {
    let mut box_0: Box_0::<T0> = Box_0 { payload: 0 as *mut T0 };
    box_0.payload = x;
    consume_box(&mut box_0);
}
