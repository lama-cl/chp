#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn f(mut x: *mut libc::c_void, mut n: libc::c_int) {
    if n <= 0 as libc::c_int {
        return;
    }
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    let mut pv: *mut libc::c_void = pc as *mut libc::c_void;
    let mut pi: *mut libc::c_int = pv as *mut libc::c_int;
    *pi += 1 as libc::c_int;
    f(pi as *mut libc::c_void, n - 1 as libc::c_int);
}
