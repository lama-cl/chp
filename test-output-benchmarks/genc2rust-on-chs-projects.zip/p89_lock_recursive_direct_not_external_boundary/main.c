#pragma merger("0","/tmp/cil-uABGIwin.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"







void f(void *x, int n) {
  if (n <= 0)
    return;

  char *pc = x;
  void *pv = pc;
  int *pi = pv;
  *pi += 1;

  f(pi, n - 1);
}
