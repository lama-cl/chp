#pragma merger("0","/tmp/cil-NJzbYmRR.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"






void *idv(void *y) {
  int *p = y;
  *p += 1;
  return p;
}

void ho(void *(*pf)(void *), void *x) {
  char *pc = x;
  pf(pc);
}
