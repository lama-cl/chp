#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn idv<T0>(mut y: *mut T0) -> *mut T0 {
    let mut p: *mut libc::c_int = y as *mut libc::c_int;
    *p += 1 as libc::c_int;
    return p as *mut T0;
}
pub unsafe extern "C" fn ho<T0>(
    mut pf: Option::<unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void>,
    mut x: *mut T0,
) {
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    pf.expect("non-null function pointer")(pc as *mut T0 as *mut libc::c_void);
}
