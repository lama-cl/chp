#pragma merger("0","/tmp/cil-sbTu6mt6.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"
void *g1(void *x) {
  int *p = x;
  *p = *p + 1;
  return p;
}

void *g2(void *x) {
  char *p = x;
  *p += 1;
  return p;
}
