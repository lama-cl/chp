#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn g1<T0>(mut x: *mut T0) -> *mut T0 {
    let mut p: *mut libc::c_int = x as *mut libc::c_int;
    *p = *p + 1 as libc::c_int;
    return p as *mut T0;
}
pub unsafe extern "C" fn g2<T0>(mut x: *mut T0) -> *mut T0 {
    let mut p: *mut libc::c_char = x as *mut libc::c_char;
    *p = (*p as libc::c_int + 1 as libc::c_int) as libc::c_char;
    return p as *mut T0;
}
