#pragma merger("0","/tmp/cil-Jta0t9Yv.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






struct Ops {
  void (*process)(void *);
};

void handle_int(void *x) {
  int *p = x;
  *p += 1;
}

void run(void *x) {
  struct Ops base = { handle_int };
  struct Ops local;
  local = base;
  local.process(x);
}
