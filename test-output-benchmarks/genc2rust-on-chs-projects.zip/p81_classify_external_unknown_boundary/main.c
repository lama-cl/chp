#pragma merger("0","/tmp/cil-gNSDBTDV.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






extern void sink(void *x);

void run(void *x) {
  sink(x);
}
