#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn handle_int<T0>(mut x: *mut T0) {
    let mut p: *mut libc::c_int = x as *mut libc::c_int;
    *p += 1 as libc::c_int;
}
pub unsafe extern "C" fn handle_char<T0>(mut x: *mut T0) {
    let mut p: *mut libc::c_char = x as *mut libc::c_char;
    *p = (*p as libc::c_int + 1 as libc::c_int) as libc::c_char;
}
