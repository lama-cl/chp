#pragma merger("0","/tmp/cil-2l5yyONT.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 9 "a.c"
struct Box {
  void *payload;
};

struct Ops {
  void (*consume)(struct Box *);
};

void consume_int_box(struct Box *b) {
  int *p = b->payload;
  *p += 1;
}

void consume_char_box(struct Box *b) {
  char *p = b->payload;
  *p += 1;
}

void run(struct Ops *ops, void *x, int tag) {
  struct Box box;
  box.payload = x;
  if (tag)
    ops->consume = consume_int_box;
  else
    ops->consume = consume_char_box;
  ops->consume(&box);
}
