#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Box_0<T0> {
    pub payload: *mut T0,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Ops {
    pub consume: Option::<unsafe extern "C" fn(*mut Box_0::<libc::c_void>) -> ()>,
}
pub unsafe extern "C" fn consume_int_box<T0>(mut b: *mut Box_0::<T0>) {
    let mut p: *mut libc::c_int = (*b).payload as *mut libc::c_int;
    *p += 1 as libc::c_int;
}
pub unsafe extern "C" fn consume_char_box<T0>(mut b: *mut Box_0::<T0>) {
    let mut p: *mut libc::c_char = (*b).payload as *mut libc::c_char;
    *p = (*p as libc::c_int + 1 as libc::c_int) as libc::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn run(
    mut ops: *mut Ops,
    mut x: *mut libc::c_void,
    mut tag: libc::c_int,
) {
    let mut box_0: Box_0::<libc::c_void> = Box_0 {
        payload: 0 as *mut libc::c_void,
    };
    box_0.payload = x;
    if tag != 0 {
        (*ops)
            .consume = Some(
            consume_int_box as unsafe extern "C" fn(*mut Box_0::<libc::c_void>) -> (),
        );
    } else {
        (*ops)
            .consume = Some(
            consume_char_box as unsafe extern "C" fn(*mut Box_0::<libc::c_void>) -> (),
        );
    }
    ((*ops).consume)
        .expect("non-null function pointer")(&mut box_0 as *mut Box_0::<libc::c_void>);
}
