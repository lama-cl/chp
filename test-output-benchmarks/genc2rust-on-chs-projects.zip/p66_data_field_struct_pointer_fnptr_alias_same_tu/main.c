#pragma merger("0","/tmp/cil-DVFXZJYm.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"
# 9 "a.c"
struct Box {
  void *payload;
};

void consume_box(struct Box *b) {
  int *p = b->payload;
  *p += 1;
}

void run(void *x) {
  struct Box box;
  box.payload = x;
  struct Box *bp = &box;
  void (*cb)(struct Box *) = consume_box;
  cb(bp);
}
