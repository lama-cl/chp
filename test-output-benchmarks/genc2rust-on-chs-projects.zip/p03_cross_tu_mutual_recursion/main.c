#pragma merger("0","/tmp/cil-xYk39a0j.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"






void f(void *);

void g(void *y) {
  f(y);
}
