#pragma merger("0","/tmp/cil-W_TXDRJj.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"


struct Box {
  void *payload;
};

struct Context {
  struct Box box;
};

void consume_int_ctx(struct Context *c) {
  int *p = c->box.payload;
  *p += 1;
}

void consume_char_ctx(struct Context *c) {
  char *p = c->box.payload;
  *p += 1;
}
