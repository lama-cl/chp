#pragma merger("0","/tmp/cil-AkIJc6xH.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"
void g1(void *y) {
  int *p = y;
  *p += 1;
}

void g2(void *y) {
  char *p = y;
  *p += 1;
}
