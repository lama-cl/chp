#pragma merger("0","/tmp/cil-tsowSfsu.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






struct Ops {
  void (*process)(void *);
};

void handle_char(void *x) {
  char *p = x;
  *p += 1;
}

void run(void *x) {
  struct Ops ops = { handle_char };
  ops.process(x);
}
