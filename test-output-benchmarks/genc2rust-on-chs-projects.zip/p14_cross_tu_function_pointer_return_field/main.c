#pragma merger("0","/tmp/cil-2bt6VWuw.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"



void *g(void *y) {
  char *p = y;
  return p;
}
