#pragma merger("0","/tmp/cil-GRHsgFsl.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"







struct Box {
  void *payload;
};

struct Ops {
  void (*consume)(struct Box *);
};

void consume_box(struct Box *b) {
  int *p = b->payload;
  *p += 1;
}

void run(void *x) {
  struct Box box;
  struct Ops ops;
  box.payload = x;
  ops.consume = consume_box;
  ops.consume(&box);
}
