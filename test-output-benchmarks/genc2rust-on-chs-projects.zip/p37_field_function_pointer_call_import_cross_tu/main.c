#pragma merger("0","/tmp/cil-gJty20eS.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"


void handle_int(void *x) {
  int *p = x;
  *p += 1;
}
