#pragma merger("0","/tmp/cil-dmABbXwG.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"







void *idv(void *x) {
  int *pi = x;
  *pi += 1;
  return pi;
}

void ho(void *(*pf)(void *), void *pvho) {
  char *pcho = pvho;
  pf(pcho);
}

void demo(void) {
  int i = 0;
  int *pi = &i;
  void *pv = pi;
  ho(idv, pv);
}
