#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn g(mut y: *mut libc::c_void) -> *mut libc::c_void {
    let mut pc: *mut libc::c_char = y as *mut libc::c_char;
    let mut pv: *mut libc::c_void = pc as *mut libc::c_void;
    let mut p: *mut libc::c_int = y as *mut libc::c_int;
    *p += 1 as libc::c_int;
    return pv;
}
