#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn g<T0>(mut y: *mut T0) -> *mut T0 {
    let mut p: *mut libc::c_char = y as *mut libc::c_char;
    return p as *mut T0;
}
