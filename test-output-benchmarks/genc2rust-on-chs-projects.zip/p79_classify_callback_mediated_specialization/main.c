#pragma merger("0","/tmp/cil-96TKK6pJ.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






void handle_int(void *x) {
  int *p = x;
  *p += 1;
}

void run(void *x) {
  void (*cb)(void *) = handle_int;
  cb(x);
}
