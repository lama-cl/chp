#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn handle_int<T0>(mut x: *mut T0) {
    let mut p: *mut libc::c_int = x as *mut libc::c_int;
    *p += 1 as libc::c_int;
}
pub unsafe extern "C" fn run<T0>(mut x: *mut T0) {
    let mut cb: Option::<unsafe extern "C" fn(*mut libc::c_void) -> ()> = Some(
        handle_int as unsafe extern "C" fn(*mut libc::c_void) -> (),
    );
    cb.expect("non-null function pointer")(x as *mut libc::c_void);
}
