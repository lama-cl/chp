#pragma merger("0","/tmp/cil-Ej076L_5.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"
extern void f(void *);

void g(void *y) {
  int *p = y;
  *p += 1;
  f(y);
}
