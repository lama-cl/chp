#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
extern "C" {
    fn f(_: *mut libc::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn g(mut y: *mut libc::c_void) {
    let mut p: *mut libc::c_int = y as *mut libc::c_int;
    *p += 1 as libc::c_int;
    f(y as *mut libc::c_void);
}
