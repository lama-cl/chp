#pragma merger("0","/tmp/cil-P38N_Syi.i","")
# 0 "a.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "a.c"






void handle_int(void *x) {
  int *p = x;
  *p += 1;
}

void handle_char(void *x) {
  char *p = x;
  *p += 1;
}

void run(void *x, int tag) {
  void (*cb)(void *) = 0;
  if (tag)
    cb = handle_int;
  else
    cb = handle_char;

  cb(x);
}
