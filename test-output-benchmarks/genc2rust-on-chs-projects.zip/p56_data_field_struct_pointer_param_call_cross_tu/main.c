#pragma merger("0","/tmp/cil-4mP6pbr_.i","")
# 0 "b.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "b.c"


struct Box {
  void *payload;
};

static void consume_int(void *x) {
  int *p = x;
  *p += 1;
}

void consume_box(struct Box *b) {
  consume_int(b->payload);
}
