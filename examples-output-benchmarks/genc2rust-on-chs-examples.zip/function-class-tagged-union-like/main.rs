#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn dispatch_by_tag(
    mut x: *mut libc::c_void,
    mut tag: libc::c_int,
) {
    if tag == 1 as libc::c_int {
        let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    } else {
        let mut pd: *mut libc::c_double = x as *mut libc::c_double;
    };
}
