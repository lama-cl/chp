#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(
    mut x: *mut libc::c_void,
    mut tag: libc::c_int,
    mut n: libc::c_int,
) {
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    let mut base: *mut libc::c_char = (pi as *mut libc::c_char).offset(n as isize);
    if tag == 1 as libc::c_int {
        let mut p1: *mut libc::c_int = base as *mut libc::c_int;
        *p1 += 1 as libc::c_int;
    } else {
        let mut p2: *mut libc::c_double = base as *mut libc::c_double;
        *p2 += 1.0f64;
    };
}
