#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn text_key_alignment(mut x: *mut libc::c_void) {
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
}
