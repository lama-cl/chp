#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub payload: *mut T0,
}
unsafe fn main_0() -> libc::c_int {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut pi: *mut libc::c_int = &mut i;
    let mut msg: Msg::<libc::c_int> = Msg {
        payload: 0 as *mut libc::c_int,
    };
    msg.payload = pi;
    let mut pi2: *mut libc::c_int = msg.payload;
    *pi2 += 1 as libc::c_int;
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
