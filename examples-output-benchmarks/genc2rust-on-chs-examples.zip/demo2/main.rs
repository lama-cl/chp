#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
unsafe fn main_0() -> libc::c_int {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut j: libc::c_int = 0 as libc::c_int;
    let mut pi1: *mut libc::c_int = &mut i;
    let mut pj1: *mut libc::c_int = &mut j;
    let mut pv: *mut libc::c_void = pi1 as *mut libc::c_void;
    pv = pj1 as *mut libc::c_void;
    let mut pc1: *mut libc::c_char = pv as *mut libc::c_char;
    let mut pi2: *mut libc::c_int = &mut i;
    let mut pj2: *mut libc::c_int = &mut j;
    let mut pv2: *mut libc::c_void = 0 as *mut libc::c_void;
    if i > 0 as libc::c_int {
        pv2 = pi2 as *mut libc::c_void;
    } else {
        pv2 = pj2 as *mut libc::c_void;
    }
    let mut pc2: *mut libc::c_char = pv2 as *mut libc::c_char;
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
