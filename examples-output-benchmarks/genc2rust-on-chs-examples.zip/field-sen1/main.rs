#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub tag: libc::c_int,
    pub payload: *mut T0,
}
unsafe fn main_0() -> libc::c_int {
    let mut x: libc::c_int = 0 as libc::c_int;
    let mut pi: *mut libc::c_int = &mut x;
    let mut pv: *mut libc::c_void = pi as *mut libc::c_void;
    let mut msg: Msg::<libc::c_void> = Msg {
        tag: 0,
        payload: 0 as *mut libc::c_void,
    };
    msg.tag = 1 as libc::c_int;
    msg.payload = pv;
    let mut pc: *mut libc::c_char = msg.payload as *mut libc::c_char;
    if msg.tag == 1 as libc::c_int {
        let mut pi_0: *mut libc::c_int = msg.payload as *mut libc::c_int;
        *pi_0 += 1 as libc::c_int;
    } else {
        let mut pc_0: *mut libc::c_char = msg.payload as *mut libc::c_char;
        *pc_0 = (*pc_0 as libc::c_int + 1 as libc::c_int) as libc::c_char;
    }
    return x;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
