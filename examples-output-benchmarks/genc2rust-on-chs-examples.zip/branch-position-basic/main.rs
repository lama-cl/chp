#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub tag: libc::c_int,
    pub payload: *mut T0,
}
#[no_mangle]
pub unsafe extern "C" fn demo(mut msg: Msg::<libc::c_void>) {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut c: libc::c_char = 0 as libc::c_int as libc::c_char;
    if msg.tag == 1 as libc::c_int {
        let mut pi: *mut libc::c_int = msg.payload as *mut libc::c_int;
        *pi += 1 as libc::c_int;
    } else {
        let mut pc: *mut libc::c_char = msg.payload as *mut libc::c_char;
        *pc = (*pc as libc::c_int + 1 as libc::c_int) as libc::c_char;
    };
}
