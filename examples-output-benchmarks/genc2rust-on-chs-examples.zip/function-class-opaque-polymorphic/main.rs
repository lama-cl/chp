#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn id_opaque<T0>(mut x: *mut T0) -> *mut T0 {
    return x;
}
