#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub payload: *mut T0,
}
unsafe fn main_0() -> libc::c_int {
    let mut address: libc::c_ulong = 0x40001000 as libc::c_int as libc::c_ulong;
    let mut ptr: *mut libc::c_int = address as *mut libc::c_int;
    let mut msg: Msg::<libc::c_void> = Msg {
        payload: 0 as *mut libc::c_void,
    };
    msg.payload = ptr as *mut libc::c_void;
    let mut pc: *mut libc::c_char = msg.payload as *mut libc::c_char;
    return (pc != 0 as *mut libc::c_char) as libc::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
