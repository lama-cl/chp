#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn f<T0>(mut x: *mut T0, mut n: libc::c_int) {
    if n <= 0 as libc::c_int {
        return;
    }
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    *pc = (*pc as libc::c_int + 1 as libc::c_int) as libc::c_char;
    f(x, n - 1 as libc::c_int);
}
