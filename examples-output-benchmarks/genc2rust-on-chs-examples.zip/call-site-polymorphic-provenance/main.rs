#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct S {
    pub x: libc::c_int,
}
#[no_mangle]
pub unsafe extern "C" fn poly(mut x: *mut libc::c_void, mut tag: libc::c_int) {
    if tag == 0 as libc::c_int {
        let mut p: *mut libc::c_int = x as *mut libc::c_int;
    } else if tag == 1 as libc::c_int {
        let mut p_0: *mut libc::c_double = x as *mut libc::c_double;
    } else {
        let mut p_1: *mut S = x as *mut S;
    };
}
#[no_mangle]
pub unsafe extern "C" fn use_int(mut p: *mut libc::c_int) {
    poly(p as *mut libc::c_void, 0 as libc::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn use_double(mut p: *mut libc::c_double) {
    poly(p as *mut libc::c_void, 1 as libc::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn use_s(mut p: *mut S) {
    poly(p as *mut libc::c_void, 2 as libc::c_int);
}
