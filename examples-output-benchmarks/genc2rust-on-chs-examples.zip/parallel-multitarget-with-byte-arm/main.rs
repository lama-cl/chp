#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut pv: *mut libc::c_void) {
    let mut pc: *mut libc::c_char = pv as *mut libc::c_char;
    let mut ps: *mut libc::c_short = pv as *mut libc::c_short;
    let mut pl: *mut libc::c_long = pv as *mut libc::c_long;
}
