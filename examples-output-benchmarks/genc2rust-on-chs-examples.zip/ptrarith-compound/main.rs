#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut x: *mut libc::c_void, mut n: libc::c_int) {
    let mut p: *mut libc::c_int = x as *mut libc::c_int;
    p = p.offset(n as isize);
    let mut pc: *mut libc::c_char = p as *mut libc::c_char;
}
