#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub payload: *mut T0,
}
pub unsafe extern "C" fn idv<T0>(mut x: *mut T0) -> *mut T0 {
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    *pi += 1 as libc::c_int;
    return pi as *mut T0;
}
pub unsafe extern "C" fn fret<T0>(mut x: *mut T0) -> *mut T0 {
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    *pc = (*pc as libc::c_int + 1 as libc::c_int) as libc::c_char;
    return x;
}
#[no_mangle]
pub unsafe extern "C" fn ho(
    mut pf: Option::<unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void>,
    mut x: *mut libc::c_void,
) {
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    pf.expect("non-null function pointer")(pc as *mut libc::c_void as *mut libc::c_void);
}
unsafe fn main_0() -> libc::c_int {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut pi: *mut libc::c_int = &mut i;
    let mut msg: Msg::<libc::c_void> = Msg {
        payload: 0 as *mut libc::c_void,
    };
    msg.payload = pi as *mut libc::c_void;
    let mut pfunc: Option::<
        unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    > = Some(idv as unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void);
    ho(pfunc, msg.payload);
    pfunc = Some(fret as unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void);
    ho(pfunc, msg.payload);
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
