#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn idv<T0>(mut x: *mut T0) -> *mut T0 {
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    return pi as *mut T0;
}
#[no_mangle]
pub unsafe extern "C" fn ho(
    mut pf: Option::<unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void>,
    mut pvho: *mut libc::c_void,
) {
    let mut pcho: *mut libc::c_char = pvho as *mut libc::c_char;
    pf
        .expect(
            "non-null function pointer",
        )(pcho as *mut libc::c_void as *mut libc::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn demo() {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut pi: *mut libc::c_int = &mut i;
    let mut pv: *mut libc::c_void = pi as *mut libc::c_void;
    ho(Some(idv as unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void), pv);
}
