#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo() {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut pi: *mut libc::c_int = &mut i;
    let mut pv: *mut libc::c_void = 0 as *mut libc::c_void;
    let mut pp: *mut *mut libc::c_void = &mut pv;
    *pp = pi as *mut libc::c_void;
    let mut pc: *mut libc::c_char = *pp as *mut libc::c_char;
}
