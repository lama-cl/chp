#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn advance_bytes<T0>(
    mut base: *mut T0,
    mut n: libc::c_int,
) -> *mut T0 {
    let mut p: *mut libc::c_char = base as *mut libc::c_char;
    p = p.offset(n as isize);
    return p as *mut T0;
}
