#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut i: libc::c_int) {
    let mut arr: [libc::c_int; 4] = [0; 4];
    let mut v: *mut libc::c_void = &mut *arr.as_mut_ptr().offset(i as isize)
        as *mut libc::c_int as *mut libc::c_void;
    let mut pc: *mut libc::c_char = v as *mut libc::c_char;
}
