#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut pc: *mut libc::c_char) {
    let mut pd: *mut libc::c_double = pc as *mut libc::c_double;
}
