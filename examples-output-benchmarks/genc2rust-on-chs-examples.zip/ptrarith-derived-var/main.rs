#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut pidv: *mut libc::c_int, mut d: libc::c_int) {
    let mut pnew: *mut libc::c_int = pidv.offset((d / 2 as libc::c_int) as isize);
    let mut pc: *mut libc::c_char = pnew as *mut libc::c_char;
}
