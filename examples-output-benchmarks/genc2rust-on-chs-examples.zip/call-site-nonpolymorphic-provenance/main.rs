#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn force_double<T0>(mut x: *mut T0) {
    let mut p: *mut libc::c_double = x as *mut libc::c_double;
}
#[no_mangle]
pub unsafe extern "C" fn use_int(mut p: *mut libc::c_int) {
    force_double(p as *mut libc::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn use_double(mut p: *mut libc::c_double) {
    force_double(p);
}
