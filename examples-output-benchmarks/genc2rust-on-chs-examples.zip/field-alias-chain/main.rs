#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub payload: *mut T0,
}
unsafe fn main_0() -> libc::c_int {
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut pi: *mut libc::c_int = &mut i;
    let mut msg: Msg::<libc::c_void> = Msg {
        payload: 0 as *mut libc::c_void,
    };
    msg.payload = pi as *mut libc::c_void;
    let mut q1: *mut libc::c_void = msg.payload;
    let mut q2: *mut libc::c_void = q1;
    let mut pc: *mut libc::c_char = q2 as *mut libc::c_char;
    *pc = (*pc as libc::c_int + 1 as libc::c_int) as libc::c_char;
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
