#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn f(mut x: *mut libc::c_void, mut n: libc::c_int) {
    if n <= 0 as libc::c_int {
        return;
    }
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    *pi += 1 as libc::c_int;
    g(pi as *mut libc::c_void, n - 1 as libc::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn g(mut y: *mut libc::c_void, mut n: libc::c_int) {
    let mut pc: *mut libc::c_char = y as *mut libc::c_char;
    *pc = (*pc as libc::c_int + 1 as libc::c_int) as libc::c_char;
    f(pc as *mut libc::c_void, n - 1 as libc::c_int);
}
