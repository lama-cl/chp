#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub tag: libc::c_int,
    pub payload: *mut T0,
}
unsafe fn main_0() -> libc::c_int {
    let mut x: libc::c_int = 0 as libc::c_int;
    let mut pv: *mut libc::c_int = &mut x;
    let mut msg: Msg::<libc::c_void> = Msg {
        tag: 0,
        payload: 0 as *mut libc::c_void,
    };
    msg.tag = 1 as libc::c_int;
    msg.payload = pv as *mut libc::c_void;
    let mut q: *mut libc::c_void = msg.payload;
    let mut pc: *mut libc::c_char = q as *mut libc::c_char;
    return x;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
