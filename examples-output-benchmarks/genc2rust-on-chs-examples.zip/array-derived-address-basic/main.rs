#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut p: *mut libc::c_int, mut i: libc::c_int) {
    let mut q: *mut libc::c_int = &mut *p.offset(i as isize) as *mut libc::c_int;
    let mut pc: *mut libc::c_char = q as *mut libc::c_char;
}
