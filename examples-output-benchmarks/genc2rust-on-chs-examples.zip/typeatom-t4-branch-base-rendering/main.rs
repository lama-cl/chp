#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Msg<T0> {
    pub tag: libc::c_int,
    pub payload: *mut T0,
}
#[no_mangle]
pub unsafe extern "C" fn branch_base_rendering(
    mut msg: Msg::<libc::c_void>,
    mut pi: *mut libc::c_int,
    mut pc0: *mut libc::c_char,
) {
    if msg.tag == 1 as libc::c_int {
        msg.payload = pi as *mut libc::c_void;
    } else {
        msg.payload = pc0 as *mut libc::c_void;
    }
    let mut q: *mut libc::c_void = msg.payload;
    let mut pc: *mut libc::c_char = q as *mut libc::c_char;
}
