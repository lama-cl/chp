#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub unsafe extern "C" fn demo<T0>(mut pv: *mut T0) {
    let mut pi: *mut libc::c_int = pv as *mut libc::c_int;
}
