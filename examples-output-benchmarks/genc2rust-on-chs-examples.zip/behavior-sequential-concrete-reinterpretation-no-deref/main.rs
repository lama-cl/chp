#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut c: *mut libc::c_char) {
    let mut i: *mut libc::c_int = c as *mut libc::c_int;
    let mut d: *mut libc::c_double = i as *mut libc::c_double;
}
