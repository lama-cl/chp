#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn reinterpret_many(mut x: *mut libc::c_void) {
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    let mut pc: *mut libc::c_char = x as *mut libc::c_char;
    let mut pd: *mut libc::c_double = pc as *mut libc::c_double;
}
