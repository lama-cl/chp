#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut p: *mut libc::c_int, mut n: libc::c_int) {
    let mut c: *mut libc::c_char = (p as *mut libc::c_char)
        .offset(
            (n as libc::c_ulong)
                .wrapping_mul(::core::mem::size_of::<libc::c_int>() as libc::c_ulong)
                as isize,
        );
    let mut q: *mut libc::c_int = c as *mut libc::c_int;
}
