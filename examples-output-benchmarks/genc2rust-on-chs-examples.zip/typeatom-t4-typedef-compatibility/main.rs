#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub type I = libc::c_int;
pub unsafe extern "C" fn typedef_compat<T0>(mut x: *mut T0) {
    let mut pi: *mut libc::c_int = x as *mut libc::c_int;
    let mut pt: *mut I = x as *mut I;
}
