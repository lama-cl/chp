#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
pub type cb_t = Option::<unsafe extern "C" fn(*mut libc::c_void) -> *mut libc::c_void>;
pub unsafe extern "C" fn higher<T0>(mut cb: cb_t, mut x: *mut T0) {
    cb.expect("non-null function pointer")(x as *mut libc::c_void);
}
