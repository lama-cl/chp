#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
#[no_mangle]
pub unsafe extern "C" fn demo(mut x: *mut libc::c_void) {
    let mut pidv: *mut libc::c_int = x as *mut libc::c_int;
    pidv = pidv.offset(4 as libc::c_int as isize);
    let mut pci: *mut libc::c_char = pidv as *mut libc::c_char;
}
