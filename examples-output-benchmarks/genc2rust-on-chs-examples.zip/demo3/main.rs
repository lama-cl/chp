#![allow(dead_code, mutable_transmutes, non_camel_case_types, non_snake_case, non_upper_case_globals, unused_assignments, unused_mut)]
unsafe fn main_0() -> libc::c_int {
    let mut address: libc::c_ulong = 0x40001000 as libc::c_int as libc::c_ulong;
    let mut ptr: *mut libc::c_int = address as *mut libc::c_int;
    let mut i: libc::c_int = 0 as libc::c_int;
    let mut j: libc::c_int = 0 as libc::c_int;
    let mut pi1: *mut libc::c_int = &mut i;
    let mut pj1: *mut libc::c_int = &mut j;
    let mut pv: *mut libc::c_void = pi1 as *mut libc::c_void;
    pv = pj1 as *mut libc::c_void;
    pv = ptr as *mut libc::c_void;
    let mut pc1: *mut libc::c_char = pv as *mut libc::c_char;
    return i;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
